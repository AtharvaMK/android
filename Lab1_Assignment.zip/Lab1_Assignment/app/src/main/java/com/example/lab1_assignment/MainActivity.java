package com.example.lab1_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void register(View view){
        EditText name = findViewById(R.id.editTextText);
        TextView text = findViewById(R.id.textView);
        text.setText(name.getText());
        CharSequence texts;

        EditText email = findViewById(R.id.editTextTextEmailAddress);
        TextView text1 = findViewById(R.id.textView1);
        text1.setText(email.getText());

        EditText phone = findViewById(R.id.editTextPhone);
        TextView text2 = findViewById(R.id.textView2);
        text2.setText(phone.getText());

        EditText address = findViewById(R.id.editTextTextPostalAddress);
        TextView text3 = findViewById(R.id.textView3);
        text3.setText(address.getText());

    }
}