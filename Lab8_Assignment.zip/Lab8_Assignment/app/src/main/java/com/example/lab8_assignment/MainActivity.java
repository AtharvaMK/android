package com.example.lab8_assignment;

import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mediaplay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaplay=null;
    }
    public void Music(View view) {
        String buttonText = getResources().getResourceEntryName(view.getId());
        switch (buttonText){
            case "Playbtn":
                if(mediaplay==null){
                    mediaplay = MediaPlayer.create(this,R.raw.sample);// create raw folder in res and add sample.mp3 in it
                }
                mediaplay.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mediaPlayer) {
                        stopMusic();}
                });
                mediaplay.start();
                break;
            case "Pausebtn":
                if(mediaplay != null)
                    mediaplay.pause();
                break;
            case "Stopbtn":
                if(mediaplay != null){
                    mediaplay.stop();
                    stopMusic();
                }
                break;
        }
    }
    private void stopMusic() {
        mediaplay.release();
        mediaplay=null;
    }
    @Override
    protected void onStop() {
        super.onStop();
        stopMusic();
    }
}
