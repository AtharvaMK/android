package com.example.lab3_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    dbHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText username=findViewById(R.id.editTextText);
        EditText password=findViewById(R.id.editTextText2);
        Button reg=findViewById(R.id.button);

        DB = new dbHelper(this);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = username.getText().toString();
                String pass = password.getText().toString();

                Boolean check =DB.checkusername(name);

                if(check==true)
                    Toast.makeText(MainActivity.this, "user is already avail", Toast.LENGTH_LONG).show();
                else
                {
                    Boolean insert=DB.insertdata(name,pass);
                    if(insert==true)
                        Toast.makeText(MainActivity.this,"user reg succ",Toast.LENGTH_LONG).show();
                    else Toast.makeText(MainActivity.this,"user reg unsucc",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}