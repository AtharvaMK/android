package com.example.lab4_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText name = findViewById(R.id.name);
        Spinner spinner = findViewById(R.id.subjectSpinner);
        Button submit = findViewById(R.id.button);
        Intent intent = new Intent(MainActivity.this, ShowActivity.class);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //for EditText
                String name1 = name.getText().toString();
                intent.putExtra("name1", name1);

                //passing the spinner
                String selectedItem = spinner.getSelectedItem().toString();
                intent.putExtra("selectedItem", selectedItem);

                startActivity(intent);
            }
        });

        //for RadioButtons
        RadioGroup radioGroup = findViewById(R.id.radiogroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int set_id = group.getCheckedRadioButtonId();
                RadioButton radioButton = findViewById(set_id);
                intent.putExtra("Gender", radioButton.getText());

            }
        });


        //for CheckBoxes
        CheckBox chk1 = (CheckBox) findViewById(R.id.checkBox1);
        CheckBox chk2 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox chk3 = (CheckBox) findViewById(R.id.checkBox3);
        CheckBox chk4 = (CheckBox) findViewById(R.id.checkBox4);

        chk1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = chk1.isChecked();
                if (checked) {
                    intent.putExtra("checkBoxx", chk1.getText());
                }
            }
        });

        chk2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = chk2.isChecked();
                if (checked) {
                    intent.putExtra("checkBoxx", chk2.getText());
                }
            }
        });

        chk3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = chk3.isChecked();
                if (checked) {
                    intent.putExtra("checkBoxx", chk3.getText());
                }
            }
        });

        chk4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean checked = chk4.isChecked();
                if (checked) {
                    intent.putExtra("checkBoxx", chk4.getText());
                }
            }
        });


        //for Spinners
        // Initialize the Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.spinner_items, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

    }
}