package com.example.lab4_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        Bundle extras = getIntent().getExtras();

        TextView textView1 = findViewById(R.id.textView1);
        textView1.setText("Name is: " + extras.getString("name1"));

        TextView textView2 = findViewById(R.id.textView2);
        textView2.setText("Gender is: " + extras.getString("Gender"));

        TextView textView3 = findViewById(R.id.textView3);
        textView3.setText("Selected Qualification is: " + extras.getString("checkBoxx"));

        TextView textView4 = findViewById(R.id.textView4);
        textView4.setText("Selected Subject is: " + extras.getString("selectedItem"));
    }
}